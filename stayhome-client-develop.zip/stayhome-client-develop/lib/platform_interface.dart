/*
 * Copyright (c) 2020 Hannah Burkhardt. All rights reserved.
 */

import 'package:map_app_flutter/platform_stub.dart';

PlatformDefs getPlatformDefs() => throw UnsupportedError("Must use a concrete implementation.");
